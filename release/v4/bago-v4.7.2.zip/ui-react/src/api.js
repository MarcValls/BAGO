import { recordInteraction } from './interactionLog'

async function resolveApiUrl() {
  // 1. Build-time override
  if (import.meta.env.VITE_BAGO_API_URL) {
    return import.meta.env.VITE_BAGO_API_URL
  }
  // 2. Electron bridge: the main process runs a local BAGO API server
  if (typeof window !== 'undefined' && window.bagoElectron?.getApiUrl) {
    try {
      const url = await window.bagoElectron.getApiUrl()
      if (url) return url
    } catch (e) {
      // fall through to defaults
    }
  }
  // 3. Vite dev server
  if (import.meta.env.DEV) {
    return 'http://127.0.0.1:8080'
  }
  // 4. Fallback for plain web preview (should not happen in Electron)
  return window.location.origin
}

let _apiUrlPromise = null
function getApiUrl() {
  if (!_apiUrlPromise) {
    _apiUrlPromise = resolveApiUrl()
  }
  return _apiUrlPromise
}

const API_TOKEN = import.meta.env.VITE_BAGO_API_TOKEN || ''

async function request(path, options = {}) {
  const API_URL = await getApiUrl()
  const headers = {
    'Content-Type': 'application/json',
    ...(API_TOKEN ? { 'X-Bago-Token': API_TOKEN } : {}),
    ...(options.headers || {}),
  }
  const body = typeof options.body === 'string' ? (() => {
    try { return JSON.parse(options.body) } catch { return options.body }
  })() : options.body || null
  recordInteraction('api-request', {
    path,
    method: options.method || 'GET',
    channel: options.headers?.['X-Bago-Channel'] || options.headers?.['x-bago-channel'] || '',
    body,
  })
  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    headers,
  })
  const data = await response.json()
  if (!response.ok) {
    throw new Error(data.error || data.message || `HTTP ${response.status}`)
  }
  recordInteraction('api-response', {
    path,
    method: options.method || 'GET',
    ok: true,
  })
  return data
}

export const chatApi = {
  getSession: () => request('/session'),
  getHistory: () => request('/history'),
  getMenu: () => request('/menu'),
  getModels: (provider) => request(`/models/${encodeURIComponent(provider)}`),
  getSimulationStatus: () => request('/simulation/status'),
  getSimulationEvents: () => request('/simulation/events'),
  getCatalogStatus: () => request('/catalog/status'),
  getRlStatus: () => request('/rl/status'),
  listFiles: () => request('/files/list').then((res) => res.entries || []),
  readFile: (filePath) => request(`/files/read/${encodeURIComponent(filePath)}`).then((res) => res.content || ''),
  sendChat: (message, channel, managerContext) => request('/chat', {
    method: 'POST',
    headers: { 'X-Bago-Channel': channel },
    body: JSON.stringify({
      message,
      channel,
      ...(managerContext ? { manager_context: managerContext } : {}),
    }),
  }),
  runCommand: (command, channel) => request('/command', {
    method: 'POST',
    headers: { 'X-Bago-Channel': channel },
    body: JSON.stringify({ command, channel }),
  }),
  switchModel: (provider, model, force = false, channel = 'desktop') => request('/switch', {
    method: 'POST',
    headers: { 'X-Bago-Channel': channel },
    body: JSON.stringify({ provider, model, force, channel }),
  }),
}

// bagoApi: alias de chatApi + endpoints adicionales usados por useBagoControl.
// Los endpoints extra (providers, simulation mode, rl shadow, catalog mode)
// se asumen soportados por el backend BAGO (VITE_BAGO_API_URL). Si alguno no
// existe, el hook captura el error y lo muestra en `error`.
export const bagoApi = {
  ...chatApi,
  getProviders: () => request('/providers'),
  setSimulationMode: (mode, enabled) => request('/simulation/config', {
    method: 'POST',
    body: JSON.stringify({ mode, enabled }),
  }),
  setRlShadow: (enabled) => request('/rl/shadow', {
    method: 'POST',
    body: JSON.stringify({ enabled }),
  }),
  setCatalogMode: (mode) => request('/catalog/config', {
    method: 'POST',
    body: JSON.stringify({ mode }),
  }),
}
