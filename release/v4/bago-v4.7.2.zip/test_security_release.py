#!/usr/bin/env python3
"""Security regression checks for the BAGO v4 distribution path."""

from __future__ import annotations

import json
import os
import sys
import tempfile
import zipfile
from pathlib import Path

BAGO_ROOT = Path(__file__).resolve().parent
CURRENT_RELEASE = (BAGO_ROOT / "release_version.txt").read_text(encoding="utf-8").strip().lstrip("v")
CURRENT_EVIDENCE_DIR = f"docs/evidence/release_{CURRENT_RELEASE.replace('.', '_')}"
sys.path.insert(0, str(BAGO_ROOT / ".bago" / "core"))
sys.path.insert(0, str(BAGO_ROOT / ".bago" / "api"))

from bridge import BagoAPIHandler, BagoAPIServer
from config_manager import ConfigManager
from session_manager import SessionManager


def test_default_auto_allow_tools_is_false() -> None:
    with tempfile.TemporaryDirectory() as td:
        cfg = ConfigManager(base_path=td)
        assert cfg.get("features.auto_allow_tools") is False


def test_state_root_is_separate_from_cwd() -> None:
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as sd:
        old = os.environ.get("BAGO_STATE_ROOT")
        os.environ["BAGO_STATE_ROOT"] = sd
        try:
            cfg = ConfigManager(base_path=td)
            assert cfg.config_path.parent.resolve() == Path(sd).resolve()
            mgr = SessionManager(base_path=td, state_root=sd)
            assert mgr.state_root.resolve() == Path(sd).resolve()
            assert mgr.state_dir.resolve() == Path(sd).resolve()
            mgr.close()
        finally:
            if old is None:
                os.environ.pop("BAGO_STATE_ROOT", None)
            else:
                os.environ["BAGO_STATE_ROOT"] = old


def test_execute_command_has_no_shell_true() -> None:
    src = (BAGO_ROOT / ".bago" / "core" / "tool_registry.py").read_text(encoding="utf-8")
    exposed = [
        line.strip()
        for line in src.splitlines()
        if "shell=True" in line and not line.strip().startswith("#")
    ]
    assert not exposed


def test_cors_does_not_allow_wildcard() -> None:
    src = (BAGO_ROOT / ".bago" / "api" / "bridge.py").read_text(encoding="utf-8")
    assert 'Access-Control-Allow-Origin", "*"' not in src
    assert "Access-Control-Allow-Origin', '*'" not in src


def test_cors_allows_only_localhost_origins() -> None:
    assert BagoAPIHandler._cors_origin_allowed("http://localhost:3000")
    assert BagoAPIHandler._cors_origin_allowed("http://127.0.0.1:8080")
    assert BagoAPIHandler._cors_origin_allowed("http://[::1]:8080")
    assert not BagoAPIHandler._cors_origin_allowed("https://example.com")
    assert not BagoAPIHandler._cors_origin_allowed("http://localhost.evil.test")


def test_non_localhost_api_requires_token() -> None:
    try:
        BagoAPIServer(object(), object(), host="0.0.0.0", token="")
    except RuntimeError:
        return
    raise AssertionError("BagoAPIServer accepted non-localhost host without token")


def test_release_package_excludes_install_config_and_includes_uninstaller() -> None:
    sys.path.insert(0, str(BAGO_ROOT / "scripts"))
    from package_v4 import build_package

    with tempfile.TemporaryDirectory() as td:
        output_dir = Path(td)
        result = build_package(BAGO_ROOT, output_dir)
        with zipfile.ZipFile(result["zip"], "r") as zf:
            names = set(zf.namelist())
            evidence_manifest = json.loads(zf.read(f"{CURRENT_EVIDENCE_DIR}/manifest.json"))
            evidence_meta = json.loads(zf.read(f"{CURRENT_EVIDENCE_DIR}/session/meta.json"))
        assert "package-lock.json" in names
        assert "install_config.json" not in names
        assert ".bago/credentials.json" not in names
        assert "bago-uninstall.ps1" in names
        assert "bago-uninstall.cmd" in names
        assert "bago_core/translators/__init__.py" in names
        assert f"{CURRENT_EVIDENCE_DIR}/manifest.json" in names
        assert f"{CURRENT_EVIDENCE_DIR}/session/meta.json" in names
        assert evidence_manifest["contract_version"] == CURRENT_RELEASE
        assert evidence_meta["bago_version"] == CURRENT_RELEASE

    # 2026-Q2 cleanup: bootstrap docs (MODEL_PARALLEL_SETUP.md, AUDIT_PARALLEL_SETUP.md)
    # were removed; install/setup guidance now lives in docs/SETUP.md.
    bootstrap_doc = BAGO_ROOT / "docs" / "SETUP.md"
    if not bootstrap_doc.exists():
        bootstrap_doc = BAGO_ROOT / "README.md"
    bootstrap = bootstrap_doc.read_text(encoding="utf-8")
    assert "ollama" in bootstrap or "install" in bootstrap, "bootstrap doc lacks install guidance"


def test_repair_only_skips_post_install_tests() -> None:
    script = (BAGO_ROOT / "install-v4.ps1").read_text(encoding="utf-8")

    assert "if ($RepairOnly)" in script
    assert "$SkipTests = $true" in script


def test_remote_installer_blocks_future_versions() -> None:
    script = (BAGO_ROOT / "install-remote.ps1").read_text(encoding="utf-8")

    assert "Get-ManagerVersion" in script
    assert "Test-ReleaseAllowed" in script
    assert "release compatible" in script


def test_manager_hides_future_versions() -> None:
    # Legacy manager/ folder was migrated to ui-react/control-plane.
    # The release filtering logic must live in the React UI source.
    script = (BAGO_ROOT / "ui-react" / "src" / "control-plane" / "views" / "ReleasesView.jsx").read_text(encoding="utf-8")

    assert "prerelease" in script
    assert "Stable" in script
    assert "Beta" in script


def test_main_process_hides_future_versions() -> None:
    script = (BAGO_ROOT / "electron" / "main.cjs").read_text(encoding="utf-8")
    release_service = (BAGO_ROOT / "electron" / "release-service.cjs").read_text(encoding="utf-8")

    assert "createDependencyService" in script
    assert "createReleaseService" in script
    assert "fetchReleases" in release_service
    assert "currentManagerVersion" in release_service
    assert "isFutureReleaseTag" in release_service


def test_manager_surfaces_startup_dependencies_and_provider_onboarding() -> None:
    main_script = (BAGO_ROOT / "electron" / "main.cjs").read_text(encoding="utf-8")
    environment = (BAGO_ROOT / "electron" / "environment.cjs").read_text(encoding="utf-8")
    ipc_service = (BAGO_ROOT / "electron" / "ipc-service.cjs").read_text(encoding="utf-8")
    window_service = (BAGO_ROOT / "electron" / "window-service.cjs").read_text(encoding="utf-8")
    dependency_service = (BAGO_ROOT / "electron" / "dependency-service.cjs").read_text(encoding="utf-8")
    runtime_service = (BAGO_ROOT / "electron" / "runtime-service.cjs").read_text(encoding="utf-8")
    install_service = (BAGO_ROOT / "electron" / "install-service.cjs").read_text(encoding="utf-8")
    release_service = (BAGO_ROOT / "electron" / "release-service.cjs").read_text(encoding="utf-8")
    # Legacy manager/ HTML/JS was migrated to ui-react/control-plane.
    react_html = (BAGO_ROOT / "ui-react" / "dist" / "index.html").read_text(encoding="utf-8")
    control_plane = (BAGO_ROOT / "ui-react" / "src" / "control-plane" / "ControlPlane.jsx").read_text(encoding="utf-8")
    preload = (BAGO_ROOT / "electron" / "preload.cjs").read_text(encoding="utf-8")
    release_job_manager = (BAGO_ROOT / "electron" / "release-job-manager.cjs").read_text(encoding="utf-8")
    chat_commands = (BAGO_ROOT / ".bago" / "chat" / "commands.py").read_text(encoding="utf-8")
    chat_repl = (BAGO_ROOT / ".bago" / "chat" / "repl.py").read_text(encoding="utf-8")
    intent_engine = (BAGO_ROOT / ".bago" / "core" / "intent_engine.py").read_text(encoding="utf-8")
    tool_registry = (BAGO_ROOT / ".bago" / "core" / "tool_registry.py").read_text(encoding="utf-8")
    command_intents = (BAGO_ROOT / ".bago" / "core" / "command_intents.json").read_text(encoding="utf-8")
    project_memory = (BAGO_ROOT / ".bago" / "tools" / "project_memory.py").read_text(encoding="utf-8")

    assert "createDependencyService" in main_script
    assert "createRuntimeService" in main_script
    assert "createInstallService" in main_script
    assert "createReleaseService" in main_script
    assert "require('./environment.cjs')" in main_script
    assert "require('./window-service.cjs')" in main_script
    assert "require('./ipc-service.cjs')" in main_script
    assert "registerIpcHandlers" in main_script
    assert "createManagerWindow()" in main_script
    assert "dependency-service.cjs" in main_script
    assert "ipcMain.handle" not in main_script
    assert "ROOT_DIR" in environment
    assert "REACT_HTML" in environment
    assert "PRELOAD_PATH" in environment
    assert "CHAT_HOST" in environment
    assert "CHAT_START_PORT" in environment
    assert "resolveBagoRuntimeRoot" in environment
    assert "resolveUiDist" in environment
    assert "resolveBundledRuntimeRoot" in environment
    assert "resolveInstalledRuntimeRoot" in environment
    assert "runVisiblePowerShell" in environment
    assert "findPackagedRuntimeRoot" in environment
    assert "registerIpcHandlers" in ipc_service
    assert "bago:dependency-action" in ipc_service
    assert "bago:node-cmd" in ipc_service
    assert "bago:release-job-start" in ipc_service
    assert "bago:release-job-delete" in ipc_service
    assert "createManagerWindow" in window_service
    assert "SMOKE_TEST" in window_service
    assert "managerHealth" in dependency_service
    assert "dependencyCatalog" in dependency_service
    assert "dependency_catalog" in dependency_service
    assert "runBagoNode" in runtime_service
    assert "ensureBagoInstalled" in install_service
    assert "ReleaseJobManager" in release_service
    assert "fetchReleases" in release_service
    assert "verify_release.py" in (BAGO_ROOT / "scripts" / "verify_release.py").read_text(encoding="utf-8")
    assert (BAGO_ROOT / "scripts" / "verify_release_463.py").exists()
    # React Control Plane is the primary UI surface
    assert "bago-ui" in react_html or "script" in react_html
    assert "ControlPlane" in control_plane
    assert "bago-cp" in control_plane
    assert "ActivityBar" in control_plane
    assert "ProjectExplorer" in control_plane
    assert "deleteReleaseJob" in preload
    assert "deleteJob" in release_job_manager
    assert "\"project\"" in chat_commands
    assert "Analiza el proyecto actual" in chat_commands
    repl_menu = (BAGO_ROOT / ".bago" / "chat" / "repl_menu.py").read_text(encoding="utf-8")
    assert "Proyecto detectado" in repl_menu
    assert "_looks_like_directory_path" in chat_repl
    assert "BAGO_INTENT_EXAMPLES_PATH" in tool_registry
    assert "BAGO_INTENT_EXAMPLES_PATH" in intent_engine
    assert "\"/project\"" in command_intents
    assert "analiza el directorio" in command_intents
    assert "analyze_data" in project_memory
    assert "format_analysis" in project_memory


if __name__ == "__main__":
    tests = [
        test_default_auto_allow_tools_is_false,
        test_state_root_is_separate_from_cwd,
        test_execute_command_has_no_shell_true,
        test_cors_does_not_allow_wildcard,
        test_cors_allows_only_localhost_origins,
        test_non_localhost_api_requires_token,
        test_release_package_excludes_install_config_and_includes_uninstaller,
        test_repair_only_skips_post_install_tests,
        test_remote_installer_blocks_future_versions,
        test_manager_hides_future_versions,
        test_main_process_hides_future_versions,
        test_manager_surfaces_startup_dependencies_and_provider_onboarding,
    ]
    for test in tests:
        test()
        print(f"PASS {test.__name__}")
