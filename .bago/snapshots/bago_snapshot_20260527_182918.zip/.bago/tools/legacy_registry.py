#!/usr/bin/env python3
"""legacy_registry.py — Comandos legacy BAGO (hyphenated aliases).

Este fichero es SOLO documentación y compatibilidad histórica.
NINGÚN comando aquí debe usarse para despacho nuevo.

Todos estos comandos fueron el método original de invocar tools BAGO
antes del registry declarativo. Se mantienen como referencia.
Nada en el launcher activo los usa — ver tool_registry.REGISTRY para
los comandos operativos actuales.

Añadido en PR-02 (registry-single-source-of-truth) del Kernel Lockdown.
"""
import os
import sys

os.environ.setdefault("PYTHONUTF8", "1")
os.environ.setdefault("PYTHONIOENCODING", "utf-8")
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

from pathlib import Path

TOOLS = Path(__file__).parent

# Snapshot histórico de comandos con guiones (CHG-002 legacy).
# Nunca se usan para despacho — solo como referencia de qué scripts existen.
LEGACY_COMMANDS: dict[str, list[str]] = {
    "alias-manager":                  ["python3", str(TOOLS / "alias_manager.py")],
    "artifact-counter":               ["python3", str(TOOLS / "artifact_counter.py")],
    "audit-v2":                       ["python3", str(TOOLS / "audit_v2.py")],
    "backup-manager":                 ["python3", str(TOOLS / "backup_manager.py")],
    "bago-consistency-check":         ["python3", str(TOOLS / "bago_consistency_check.py")],
    "bago-typing-course-analyzer":    ["python3", str(TOOLS / "bago_typing_course_analyzer.py")],
    "build-cleaner":                  ["python3", str(TOOLS / "build_cleaner.py")],
    "build-runner":                   ["python3", str(TOOLS / "build_runner.py")],
    "cabinet-orchestrator":           ["python3", str(TOOLS / "cabinet_orchestrator.py")],
    "changelog-gen":                  ["python3", str(TOOLS / "changelog_gen.py")],
    "check-validate-purity":          ["python3", str(TOOLS / "check_validate_purity.py")],
    "chronicle-reporter":             ["python3", str(TOOLS / "chronicle_reporter.py")],
    "clean-artifacts":                ["python3", str(TOOLS / "clean_artifacts.py")],
    "code-metrics":                   ["python3", str(TOOLS / "code_metrics.py")],
    "code-quality-orchestrator":      ["python3", str(TOOLS / "code_quality_orchestrator.py")],
    "code-search":                    ["python3", str(TOOLS / "code_search.py")],
    "commit-readiness":               ["python3", str(TOOLS / "commit_readiness.py")],
    "competition-report":             ["python3", str(TOOLS / "competition_report.py")],
    "config-check":                   ["python3", str(TOOLS / "config_check.py")],
    "config-show":                    ["python3", str(TOOLS / "config_show.py")],
    "config-wizard":                  ["python3", str(TOOLS / "config_wizard.py")],
    "context-detector":               ["python3", str(TOOLS / "context_detector.py")],
    "context-map":                    ["python3", str(TOOLS / "context_map.py")],
    "cosecha":                        ["python3", str(TOOLS / "cosecha.py")],
    "dashboard-v2":                   ["python3", str(TOOLS / "dashboard_v2.py")],
    "dep-audit":                      ["python3", str(TOOLS / "dep_audit.py")],
    "deps-check":                     ["python3", str(TOOLS / "deps_check.py")],
    "disk-usage":                     ["python3", str(TOOLS / "disk_usage.py")],
    "doctor":                         ["python3", str(TOOLS / "doctor.py")],
    "efficiency-meter":               ["python3", str(TOOLS / "efficiency_meter.py")],
    "emit-ideas":                     ["python3", str(TOOLS / "emit_ideas.py")],
    "env-check":                      ["python3", str(TOOLS / "env_check.py")],
    "env-diff":                       ["python3", str(TOOLS / "env_diff.py")],
    "env-manager":                    ["python3", str(TOOLS / "env_manager.py")],
    "env-setup":                      ["python3", str(TOOLS / "env_setup.py")],
    "file-diff":                      ["python3", str(TOOLS / "file_diff.py")],
    "flow":                           ["python3", str(TOOLS / "flow.py")],
    "focus-mode":                     ["python3", str(TOOLS / "focus_mode.py")],
    "generate-bago-evolution-report": ["python3", str(TOOLS / "generate_bago_evolution_report.py")],
    "git-context":                    ["python3", str(TOOLS / "git_context.py")],
    "git-status":                     ["python3", str(TOOLS / "git_status.py")],
    "health-check":                   ["python3", str(TOOLS / "health_check.py")],
    "health-report":                  ["python3", str(TOOLS / "health_report.py")],
    "health-score":                   ["python3", str(TOOLS / "health_score.py")],
    "html-export":                    ["python3", str(TOOLS / "html_export.py")],
    # Experimental LAN helper; binds 0.0.0.0 by design for local-network discovery.
    "http-discover":                  ["python3", str(TOOLS / "http_discover.py")],
    "ideas-selector":                 ["python3", str(TOOLS / "ideas_selector.py")],
    "image-gen":                      ["python3", str(TOOLS / "image_gen.py")],
    "infra-parity":                   ["python3", str(TOOLS / "infra_parity.py")],
    "inspect-workflow":               ["python3", str(TOOLS / "inspect_workflow.py")],
    "intent-router":                  ["python3", str(TOOLS / "intent_router.py")],
    "lint-runner":                    ["python3", str(TOOLS / "lint_runner.py")],
    "live-dashboard":                 ["python3", str(TOOLS / "live_dashboard.py")],
    "log-viewer":                     ["python3", str(TOOLS / "log_viewer.py")],
    "logs-tail":                      ["python3", str(TOOLS / "logs_tail.py")],
    "lsp-manager":                    ["python3", str(TOOLS / "lsp_manager.py")],
    "metrics-export":                 ["python3", str(TOOLS / "metrics_export.py")],
    "naming-check":                   ["python3", str(TOOLS / "naming_check.py")],
    "net-interact":                   ["python3", str(TOOLS / "net_interact.py")],
    "net-scan":                       ["python3", str(TOOLS / "net_scan.py")],
    "notifier":                       ["python3", str(TOOLS / "notifier.py")],
    "open-file":                      ["python3", str(TOOLS / "open_file.py")],
    "outdated-check":                 ["python3", str(TOOLS / "outdated_check.py")],
    "pack-dashboard":                 ["python3", str(TOOLS / "pack_dashboard.py")],
    "peer-link":                      ["python3", str(TOOLS / "peer_link.py")],
    "personality-panel":              ["python3", str(TOOLS / "personality_panel.py")],
    "ping-server":                    ["python3", str(TOOLS / "ping_server.py")],
    "port-kill":                      ["python3", str(TOOLS / "port_kill.py")],
    "port-table":                     ["python3", str(TOOLS / "port_table.py")],
    "ports-check":                    ["python3", str(TOOLS / "ports_check.py")],
    "project-init":                   ["python3", str(TOOLS / "project_init.py")],
    "project-summary":                ["python3", str(TOOLS / "project_summary.py")],
    "recent-projects":                ["python3", str(TOOLS / "recent_projects.py")],
    "reconcile-state":                ["python3", str(TOOLS / "reconcile_state.py")],
    "role-contract-validator":        ["python3", str(TOOLS / "role_contract_validator.py")],
    "repo-clone":                     ["python3", str(TOOLS / "repo_clone.py")],
    "repo-context-guard":             ["python3", str(TOOLS / "repo_context_guard.py")],
    "repo-list":                      ["python3", str(TOOLS / "repo_list.py")],
    "repo-switch":                    ["python3", str(TOOLS / "repo_switch.py")],
    "research-orchestrator":          ["python3", str(TOOLS / "research_orchestrator.py")],
    "restore":                        ["python3", str(TOOLS / "restore.py")],
    "rule-catalog":                   ["python3", str(TOOLS / "rule_catalog.py")],
    "script-runner":                  ["python3", str(TOOLS / "script_runner.py")],
    "search-history":                 ["python3", str(TOOLS / "search_history.py")],
    "security-audit":                 ["python3", str(TOOLS / "security_audit.py")],
    "session-close-generator":        ["python3", str(TOOLS / "session_close_generator.py")],
    "session-opener":                 ["python3", str(TOOLS / "session_opener.py")],
    "session-preflight":              ["python3", str(TOOLS / "session_preflight.py")],
    "session-stats":                  ["python3", str(TOOLS / "session_stats.py")],
    "show-task":                      ["python3", str(TOOLS / "show_task.py")],
    "sincerity-detector":             ["python3", str(TOOLS / "sincerity_detector.py")],
    "snapshot":                       ["python3", str(TOOLS / "snapshot.py")],
    "snapshot-compare":               ["python3", str(TOOLS / "snapshot_compare.py")],
    "sprint":                         ["python3", str(TOOLS / "sprint.py")],
    "sprint-summary":                 ["python3", str(TOOLS / "sprint_summary.py")],
    "stability-summary":              ["python3", str(TOOLS / "stability_summary.py")],
    "stale-detector":                 ["python3", str(TOOLS / "stale_detector.py")],
    "state-manager":                  ["python3", str(TOOLS / "state_manager.py")],
    "stats":                          ["python3", str(TOOLS / "stats.py")],
    "sync-pack-metadata":             ["python3", str(TOOLS / "sync_pack_metadata.py")],
    "sync-state":                     ["python3", str(TOOLS / "sync_state.py")],
    "template-gen":                   ["python3", str(TOOLS / "template_gen.py")],
    "test-runner":                    ["python3", str(TOOLS / "test_runner.py")],
    "timeline":                       ["python3", str(TOOLS / "timeline.py")],
    "todo-scan":                      ["python3", str(TOOLS / "todo_scan.py")],
    "tool-registry":                  ["python3", str(TOOLS / "tool_registry.py")],
    "tool-search":                    ["python3", str(TOOLS / "tool_search.py")],
    "tool-watcher":                   ["python3", str(TOOLS / "tool_watcher.py")],
    "type-check":                     ["python3", str(TOOLS / "type_check.py")],
    "v2-close-checklist":             ["python3", str(TOOLS / "v2_close_checklist.py")],
    "validate-manifest":              ["python3", str(TOOLS / "validate_manifest.py")],
    "validate-pack":                  ["python3", str(TOOLS / "validate_pack.py")],
    "validate-state":                 ["python3", str(TOOLS / "validate_state.py")],
    "vertice-activator":              ["python3", str(TOOLS / "vertice_activator.py")],
    "watch-files":                    ["python3", str(TOOLS / "watch_files.py")],
    "weekly-report":                  ["python3", str(TOOLS / "weekly_report.py")],
    "why":                            ["python3", str(TOOLS / "why.py")],
    "db":                             ["python3", str(TOOLS / "bago_db.py")],
    "hello":                          ["python3", str(TOOLS / "bago_hello.py")],
    "next":                           ["python3", str(TOOLS / "bago_next.py")],
    "diff":                           ["python3", str(TOOLS / "bago_diff.py")],
    "status":                         ["python3", str(TOOLS / "flow.py"), "status"],
    "done":                           ["python3", str(TOOLS / "show_task.py"), "--done"],
    "workflow-navigator":             ["python3", str(TOOLS / "workflow_navigator.py")],
    "workflow-selector":              ["python3", str(TOOLS / "workflow_selector.py")],
}

# ── ESTADO DEL INVENTARIO ────────────────────────────────────────────────────
# Promovidos al registry activo (ver _registry_entries.py, bloque LEGACY PROMOVIDOS):
#   alias-manager, artifact-counter, code-metrics, code-search,
#   env-manager, focus-mode, git-status, html-export, lint-runner,
#   log-viewer, net-scan, personality-panel, ping-server, project-summary,
#   script-runner, search-history, state-manager, template-gen,
#   weekly-report, workflow-navigator
# Entradas eliminadas por .py inexistente:
#   (ninguna — todos los 125 archivos .py referenciados existen en .bago/tools/)
# Restantes como referencia histórica: 125 entradas
