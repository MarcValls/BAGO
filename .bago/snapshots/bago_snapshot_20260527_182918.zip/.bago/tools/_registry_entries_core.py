"""_registry_entries_core.py — Subset of BAGO tool registry."""
from __future__ import annotations

import os
import sys

os.environ.setdefault("PYTHONUTF8", "1")
os.environ.setdefault("PYTHONIOENCODING", "utf-8")
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

from _registry_models import PreflightCheck, ToolEntry
from _registry_paths import BAGO_ROOT, TOOLS_DIR

_ENTRIES: dict[str, ToolEntry] = {
    "dashboard": ToolEntry(
        cmd="dashboard", module="pack_dashboard",
        description="Muestra el dashboard del pack (--public para vista publicable)",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "pack_dashboard.py"))],
    ),
    "stats-panel": ToolEntry(
        cmd="stats-panel", module="pack_dashboard",
        description="Panel de estadisticas de BAGO (--public)",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "pack_dashboard.py"))],
    ),
    "publish-kit": ToolEntry(
        cmd="publish-kit", module="publish_kit",
        description="Genera notas de release y textos cortos para publicar BAGO",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "publish_kit.py"))],
        layer="generacion",
        scope="framework",
        agent="DOCUMENTADOR",
        stability="experimental",
        risk="mutating",
        supports_dry_run=False,
    ),
    "demo": ToolEntry(
        cmd="demo", module="bago_demo",
        description="Entrada demo de BAGO: dashboard publico, publish-kit y miniapp local",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "bago_demo.py"))],
        layer="interfaz",
        scope="framework",
        agent="MAESTRO_BAGO",
        stability="experimental",
        risk="safe",
        supports_dry_run=False,
    ),
    "ideas": ToolEntry(
        cmd="ideas", module="emit_ideas",
        description="Emite ideas W2",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "emit_ideas.py"))],
    ),
    "cosecha": ToolEntry(
        cmd="cosecha", module="cosecha",
        description="Cosecha de artefactos del proyecto",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "cosecha.py"))],
        deprecated=True, see_also="bago session harvest",
    ),
    "detector": ToolEntry(
        cmd="detector", module="context_detector",
        description="Detector de contexto del repo",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "context_detector.py"))],
        deprecated=True, see_also="bago context detect",
    ),
    "validate": ToolEntry(
        cmd="validate", module="validate",
        description="Verifica el pack (manifiesto, estado, roles, ZIP) — subcomandos: manifest, state, contents",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "validate.py"))],
    ),
    "smoke": ToolEntry(
        cmd="smoke", module="smoke_runner",
        description="Smoke del pack: validate_pack + health_score + última cosecha cerrada",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "smoke_runner.py"))],
        layer="calidad", scope="framework",
        agent="CENTINELA",
        stability="core",
        risk="safe",
        preflight_policy="optional",
    ),
    "docs": ToolEntry(
        cmd="docs", module="generate_commands_doc",
        description="Genera docs/COMMANDS.md desde tool_registry.py (fuente única de verdad)",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "generate_commands_doc.py"))],
        layer="calidad", scope="framework",
    ),
    "doc-agent": ToolEntry(
        cmd="doc-agent", module="doc_agent",
        description=(
            "Agente de documentación: detecta y actualiza COMMANDS.md, LAYERS.md y README.md. "
            "Subcomandos/flags: --check | --dry-run | --json | --only <doc> | --no-stage"
        ),
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "doc_agent.py"))],
        layer="calidad",
        scope="framework",
        agent="CENTINELA",
        stability="core",
        risk="mutating",
        preflight_policy="required",
        supports_dry_run=True,
        layer_group="core",
    ),
    "sync": ToolEntry(
        cmd="sync", module="sync_pack_metadata",
        description="Regenera TREE.txt y CHECKSUMS",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "sync_pack_metadata.py"))],
    ),
    "pack-cache": ToolEntry(
        cmd="pack-cache", module="pack_cache_db",
        description="Cache híbrida pack.json -> bago.db (sync | check | status)",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "pack_cache_db.py"))],
        preflight_policy="required",
        layer="infraestructura", scope="framework", agent="ARQUITECTO",
        stability="core", risk="safe",
    ),
    "check": ToolEntry(
        cmd="check", module="check_validate_purity",
        description="Chequeo estático de pureza",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "check_validate_purity.py"))],
        deprecated=True, see_also="bago audit purity",
    ),
    "health": ToolEntry(
        cmd="health", module="health",
        description="Salud del framework: score | report | stability | efficiency | consistency | sincerity",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "health" / "__main__.py"))],
    ),
    "audit": ToolEntry(
        cmd="audit", module="audit",
        description="Auditoría y calidad: full | pack | scan | commit | push | doctor | heal | quality | purity",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "audit" / "__main__.py"))],
    ),
    "update": ToolEntry(
        cmd="update", module="bago_update",
        description="Busca GitHub releases, actualiza BAGO y ofrece beta instalable cuando existe",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "bago_update.py"))],
        stability="experimental",
        risk="mutating",
        preflight_policy="optional",
        supports_dry_run=True,
    ),
    "restart": ToolEntry(
        cmd="restart", module="bago_restart",
        description="Reinicia la consola de BAGO y recarga el runtime activo",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "bago_restart.py"))],
        stability="experimental",
        risk="safe",
        preflight_policy="optional",
    ),
    "route-graph": ToolEntry(
        cmd="route-graph", module="route_graph",
        description="Muestra el routing como grafo ASCII de nodos, cadena de modelos y gate de contrato",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "route_graph.py"))],
        stability="experimental",
        risk="safe",
        preflight_policy="optional",
    ),
    "preset": ToolEntry(
        cmd="preset", module="bago_preset",
        description="Gestiona presets estaticos del runtime: list | show | apply <nombre>",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "bago_preset.py"))],
        stability="experimental",
        risk="safe",
        preflight_policy="optional",
    ),
    "contract": ToolEntry(
        cmd="contract", module="bago_contract",
        description="Gestiona el contrato de salida: show | set <texto> | clear | infer --task",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "bago_contract.py"))],
        stability="experimental",
        risk="safe",
        preflight_policy="optional",
    ),
    "version": ToolEntry(
        cmd="version", module="bago_version",
        description="Gestión de versiones beta/release: bump | beta | release | tag | commit | sync-check",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "bago_version.py"))],
        stability="experimental",
        risk="mutating",
        preflight_policy="optional",
    ),
    "workflow": ToolEntry(
        cmd="workflow", module="workflow_selector",
        description="Selector de workflow (interactivo)",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "workflow_selector.py"))],
    ),
    "stale": ToolEntry(
        cmd="stale", module="stale_detector",
        description="Detecta tools obsoletas o sin mantenimiento",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "stale_detector.py"))],
        deprecated=True, see_also="bago context stale",
    ),
    "v2": ToolEntry(
        cmd="v2", module="v2_close_checklist",
        description="Checklist de cierre v2",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "v2_close_checklist.py"))],
        deprecated=True, see_also="bago session v2",
    ),
    "task": ToolEntry(
        cmd="task", module="show_task",
        description="Muestra la tarea W2 pendiente. --done | --assign <agente> | --clear",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "show_task.py"))],
    ),
    "assign": ToolEntry(
        cmd="assign", module="task_assign",
        description="Asigna tareas a agentes/roles. list-agents | assign <id> <agente> | pending | assigned",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "task_assign.py"))],
    ),
    "benchmark": ToolEntry(
        cmd="benchmark", module="bago_benchmark",
        description="Banco de pruebas de eficiencia BAGO (10 min). --duration N | --suite fast|full | --json",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "bago_benchmark.py"))],
    ),
    "stability": ToolEntry(
        cmd="stability", module="stability_summary",
        description="Resumen de estabilidad del pack",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "stability_summary.py"))],
        deprecated=True, see_also="bago health stability",
    ),
    "session": ToolEntry(
        cmd="session", module="session",
        description="Ciclo de sesión: open | close | harvest | v2",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "session" / "__main__.py"))],
    ),
    "efficiency": ToolEntry(
        cmd="efficiency", module="efficiency_meter",
        description="Medidor de eficiencia inter-versiones",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "efficiency_meter.py"))],
        deprecated=True, see_also="bago health efficiency",
    ),
    "sincerity": ToolEntry(
        cmd="sincerity", module="sincerity_detector",
        description="Centinela de sinceridad: detecta sincofancía en docs .md",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "sincerity_detector.py"))],
        deprecated=True, see_also="bago health sincerity",
    ),
    "scope": ToolEntry(
        cmd="scope", module="scope_detector",
        description="Detecta scope (framework/project/both) de scripts Python por análisis estático",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "scope_detector.py"))],
    ),
    "cabinet": ToolEntry(
        cmd="cabinet", module="cabinet_orchestrator",
        description="Gabinete BAGO: orquesta agentes en paralelo e informa unificado",
        preflight=[PreflightCheck("file", str(TOOLS_DIR / "cabinet_orchestrator.py"))],
    ),
}
