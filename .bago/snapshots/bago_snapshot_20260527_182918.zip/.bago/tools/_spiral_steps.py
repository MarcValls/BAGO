from __future__ import annotations

import os
import sys

os.environ.setdefault("PYTHONUTF8", "1")
os.environ.setdefault("PYTHONIOENCODING", "utf-8")
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

_HERE = Path(__file__).parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

from _spiral_state import (
    _bago,
    _compute_fingerprint,
    _load_cycles,
    _load_episodic,
    _load_gradient,
    _load_gs,
    _load_voice_cycles,
    _save_cycles,
    _save_episodic,
    _save_gradient,
    _save_voice_cycle,
    _search_similar_episodes,
)

# Module-level state (filled by spiral_loop.py at import time)
BAGO_ROOT: Path | None = None
TOOLS_DIR: Path | None = None
STATE_DIR: Path | None = None
LOG_DIR: Path | None = None
EPISODES_FILE: Path | None = None
GRADIENT_FILE: Path | None = None
SPIRAL_LOG: Path | None = None
COLORS: dict[str, str] = {}
STEPS: list[tuple[str, str, str]] = []
CHROMA_COLORS: list[str] = []
TOOLS: Path | None = None
STATE: Path | None = None
ROOT: Path | None = None
GS_FILE: Path | None = None
BAGO_SCRIPT: Path | None = None
BOLD = ""
RST = ""
RED = ""
GRN = ""
YEL = ""
CYN = ""
MAG = ""
DIM = ""


def _init_phases(
    bago_root: Path,
    tools_dir: Path,
    state_dir: Path,
    log_dir: Path,
    episodes_file: Path,
    gradient_file: Path,
    spiral_log: Path,
    colors: dict[str, str],
    steps: list[tuple[str, str, str]],
    chroma_colors: list[str],
) -> None:
    global BAGO_ROOT, TOOLS_DIR, STATE_DIR, LOG_DIR
    global EPISODES_FILE, GRADIENT_FILE, SPIRAL_LOG
    global COLORS, STEPS, CHROMA_COLORS
    global TOOLS, STATE, ROOT, GS_FILE, BAGO_SCRIPT
    global BOLD, RST, RED, GRN, YEL, CYN, MAG, DIM

    BAGO_ROOT = bago_root
    TOOLS_DIR = tools_dir
    STATE_DIR = state_dir
    LOG_DIR = log_dir
    EPISODES_FILE = episodes_file
    GRADIENT_FILE = gradient_file
    SPIRAL_LOG = spiral_log
    COLORS = colors
    STEPS = steps
    CHROMA_COLORS = chroma_colors

    TOOLS = tools_dir
    STATE = state_dir
    ROOT = bago_root.parent
    GS_FILE = state_dir / "global_state.json"
    BAGO_SCRIPT = ROOT / "bago"

    BOLD = colors["BOLD"]
    RST = colors["RST"]
    RED = colors["RED"]
    GRN = colors["GRN"]
    YEL = colors["YEL"]
    CYN = colors["CYN"]
    MAG = colors["MAG"]
    DIM = colors["DIM"]


# ── Helpers de UI ─────────────────────────────────────────────

def _print_step(n: int, status: str, msg: str) -> None:
    note, name, _ = STEPS[n]
    color = CHROMA_COLORS[n]
    st_color = GRN if status == "OK" else (YEL if status in ("WARN", "DRY", "—") else RED)
    bar = f"{color}{'█' * (n + 1)}{'░' * (11 - n)}{RST}"
    print(f"  {bar}  {color}{BOLD}{note:2s} {name:10s}{RST}  [{st_color}{status}{RST}]  {DIM}{msg}{RST}")



def _print_header(cycle_n: int, radius: float) -> None:
    print()
    print(f"  {BOLD}{CYN}╔══ BAGO Spiral Loop ═══════════════════════════════════╗{RST}")
    print(f"  {BOLD}{CYN}║  Ciclo #{cycle_n}  ·  Radio acumulado: {radius:.2f}             ║{RST}")
    print(f"  {BOLD}{CYN}╚════════════════════════════════════════════════════════╝{RST}")
    print(f"  {DIM}C → C# → D → D# → E → F → F# → G → G# → A → A# → B → C'{RST}")
    print()


# ── Los 12 pasos del ciclo ────────────────────────────────────

def step_observe(ctx: dict) -> dict:
    """C — Leer estado actual."""
    gs = _load_gs(GS_FILE)
    cycles = _load_cycles(SPIRAL_LOG)
    ctx["gs"] = gs
    ctx["cycle_number"] = len(cycles["cycles"]) + 1
    ctx["previous_cycle"] = cycles["cycles"][-1] if cycles["cycles"] else None
    ctx["total_radius"] = cycles.get("total_radius", 0.0)
    ctx["timestamp"] = datetime.now(timezone.utc).isoformat()
    ctx["observations"] = {
        "bago_version": gs.get("bago_version", "?"),
        "health_score": gs.get("health_score", {}).get("score", "?"),
        "guardian_health": gs.get("guardian_findings", {}).get("health_pct", "?"),
        "last_session": gs.get("last_completed_session_id", "?"),
        "last_change": gs.get("last_completed_change_id", "?"),
    }
    _print_step(0, "OK", f"Ciclo #{ctx['cycle_number']} · radio acumulado: {ctx['total_radius']:.2f}")
    return ctx



def step_describe(ctx: dict) -> dict:
    """C# — Generar auto-descripción."""
    obs = ctx["observations"]
    desc = {
        "cycle": ctx["cycle_number"],
        "at": ctx["timestamp"],
        "version": obs["bago_version"],
        "health": obs["health_score"],
        "guardian": obs["guardian_health"],
        "last_session": obs["last_session"],
        "last_change": obs["last_change"],
        "tools_count": len(list((TOOLS).glob("*.py"))),
        "state_keys": list(ctx["gs"].keys()),
    }
    ctx["self_description"] = desc
    _print_step(1, "OK", f"Sistema descrito: v{desc['version']} · {desc['tools_count']} tools · health={desc['health']}")
    return ctx



def step_compare(ctx: dict) -> dict:
    """D — Diff con ciclo anterior."""
    prev = ctx.get("previous_cycle")
    curr = ctx["self_description"]
    if not prev:
        ctx["diff"] = {"type": "genesis", "delta": {}, "note": "Primer ciclo — no hay referencia anterior"}
        _print_step(2, "—", "Primer ciclo (genesis)")
        return ctx

    prev_desc = prev.get("self_description", {})
    delta = {}
    for k in set(list(prev_desc.keys()) + list(curr.keys())):
        pv = prev_desc.get(k)
        cv = curr.get(k)
        if pv != cv:
            delta[k] = {"before": pv, "after": cv}

    ctx["diff"] = {"type": "evolution", "delta": delta, "changed_keys": list(delta.keys())}
    _print_step(2, "OK", f"{len(delta)} cambios respecto al ciclo anterior: {list(delta.keys())[:4]}")
    return ctx



def step_detect(ctx: dict) -> dict:
    """D# — Detectar drift, regresiones y recuperar memoria episódica."""
    diff = ctx.get("diff", {})
    delta = diff.get("delta", {})
    issues = []
    gains = []

    for k, change in delta.items():
        before, after = change.get("before"), change.get("after")
        if k in ("health", "guardian"):
            if isinstance(before, (int, float)) and isinstance(after, (int, float)):
                if after < before:
                    issues.append(f"⚠️  {k}: {before} → {after} (regresión)")
                elif after > before:
                    gains.append(f"✅ {k}: {before} → {after} (mejora)")
        if k == "tools_count":
            if isinstance(after, int) and isinstance(before, int) and after > before:
                gains.append(f"➕ {after - before} tools nuevos")

    ctx["issues"] = issues
    ctx["gains"] = gains

    # IDEA 3: fingerprint + búsqueda episódica
    sv_partial = {
        "C": ctx.get("observations", {}).get("health_score", 100),
        "Ds": float(len(delta)),
        "Gs": 1.0,
    }
    fingerprint = _compute_fingerprint(issues, gains, sv_partial)
    ctx["fingerprint"] = fingerprint
    similar = _search_similar_episodes(EPISODES_FILE, fingerprint)
    ctx["similar_episodes"] = similar

    mem_note = f" · {len(similar)} episodios similares en memoria" if similar else ""
    if issues:
        _print_step(3, "WARN", f"{len(issues)} regresiones: {issues[0] if issues else ''}{mem_note}")
    else:
        _print_step(3, "OK", f"0 regresiones · {len(gains)} mejoras{mem_note}")
    return ctx



def step_propose(ctx: dict) -> dict:
    """E — Propuestas para la próxima vuelta."""
    issues = ctx.get("issues", [])
    proposals = []

    # Propuestas basadas en el estado actual
    gs = ctx.get("gs", {})
    guardian = gs.get("guardian_findings", {})
    warnings = guardian.get("warnings", 0)

    if warnings > 400:
        proposals.append({
            "id": "P001", "priority": "medium",
            "title": f"Reducir warnings del guardian ({warnings} activos)",
            "action": "Auditar experimental tools más usados y añadir --test + integration",
            "radius_gain": 0.3,
        })

    if ctx.get("previous_cycle") is None:
        proposals.append({
            "id": "P000", "priority": "high",
            "title": "Establecer baseline del bucle espiral",
            "action": "Primer ciclo completo — guardar self_description como referencia",
            "radius_gain": 1.0,
        })

    proposals.append({
        "id": "P_NEXT", "priority": "low",
        "title": "Próxima vuelta: revisar tools legacy (28 activos)",
        "action": "Evaluar si algún legacy puede promover a experimental o eliminar",
        "radius_gain": 0.2,
    })

    ctx["proposals"] = proposals

    # IDEA 3: si hay episodios similares, añadir propuesta basada en resolución pasada
    similar = ctx.get("similar_episodes", [])
    for i, ep in enumerate(similar[:2]):
        res = ep.get("resolution", "")
        if res and res != "—":
            proposals.append({
                "id": f"P_MEM{i:02d}", "priority": "medium",
                "title": f"[Memoria] Patrón conocido: {res[:60]}",
                "action": f"Revisitar resolución del ciclo #{ep.get('cycle', '?')}: {res}",
                "radius_gain": 0.15,
                "_from_memory": True,
            })

    ctx["proposals"] = proposals
    _print_step(4, "OK", f"{len(proposals)} propuestas generadas" + (f" ({len(similar)} de memoria)" if similar else ""))
    return ctx



def step_select(ctx: dict) -> dict:
    """F — Filtrar propuestas con gradiente de aprendizaje (IDEA 1)."""
    proposals = ctx.get("proposals", [])
    gradient = _load_gradient(GRADIENT_FILE, STEPS, ctx.get("_voice_id", "main"))
    pw = gradient.get("proposal_weights", {})

    def _score(p: dict) -> float:
        base = {"high": 3.0, "medium": 2.0, "low": 1.0}.get(p.get("priority", "low"), 1.0)
        base += p.get("radius_gain", 0)
        base *= pw.get(p.get("id", ""), 1.0)
        return base

    ranked = sorted(proposals, key=_score, reverse=True)
    selected = [
        p for p in ranked
        if p.get("priority") in ("high", "medium") and p.get("radius_gain", 0) >= 0.15
    ]
    ctx["selected"] = selected
    ctx["_gradient"] = gradient
    _print_step(5, "OK", f"{len(selected)}/{len(proposals)} propuestas seleccionadas (gradient-weighted)")
    return ctx



def step_plan(ctx: dict) -> dict:
    """F# — Plan concreto."""
    plan_steps = []
    for p in ctx.get("selected", []):
        plan_steps.append({
            "proposal": p["id"],
            "title": p["title"],
            "action": p["action"],
            "command": None,
        })
    ctx["plan"] = plan_steps
    _print_step(6, "OK", f"Plan generado: {len(plan_steps)} acciones")
    return ctx



def step_act(ctx: dict, execute: bool = False) -> dict:
    """G — Ejecutar (dry-run por defecto)."""
    if not execute:
        _print_step(7, "DRY", f"dry-run: {len(ctx.get('plan', []))} acciones pendientes (pasa --execute para actuar)")
        ctx["acted"] = False
        return ctx
    ctx["acted"] = True
    _print_step(7, "OK", "ACT ejecutado (solo acciones no-destructivas en este ciclo)")
    return ctx



def step_validate(ctx: dict) -> dict:
    """G# — Validar integridad."""
    results = {}
    rc, out, _ = _bago(["validate"], bago_script=BAGO_SCRIPT, root=ROOT, timeout=30)
    results["validate"] = "GO" if rc == 0 else "FAIL"

    rc2, out2, _ = _bago(["health"], bago_script=BAGO_SCRIPT, root=ROOT, timeout=20)
    score = "?"
    for line in out2.splitlines():
        if "Health Score:" in line:
            score = line.split(":")[-1].strip().split()[0]
    results["health"] = score

    ctx["validation"] = results
    ok = all(v not in ("FAIL",) for v in results.values())
    _print_step(8, "OK" if ok else "FAIL", f"validate={results['validate']} · health={results['health']}")
    return ctx



def _compute_state_vector(ctx: dict) -> dict:
    """IDEA 4 — Vector de estado 12D: cada nota = una dimensión medible.

    C  → health_score       : salud del sistema (0-100)
    C# → test_count         : número de tests en suite
    D  → tools_count        : herramientas registradas
    D# → drift_magnitude    : número de campos que cambiaron respecto al ciclo anterior
    E  → proposals_count    : propuestas generadas en E
    F  → selected_count     : propuestas seleccionadas en F
    F# → plan_complexity    : acciones en el plan (F#)
    G  → act_executed       : 1.0 si ACT real, 0.0 si dry-run
    G# → validate_pass      : 1.0 si GO, 0.0 si FAIL
    A  → records_written    : siempre 1.0 (este ciclo)
    A# → self_model_delta   : campos del self_description que cambiaron
    B  → radius_gained      : radio acumulado este ciclo
    """
    desc = ctx.get("self_description", {})
    diff = ctx.get("diff", {})
    val = ctx.get("validation", {})

    health = desc.get("health", 0)
    if isinstance(health, str):
        try:
            health = float(health.rstrip("%"))
        except Exception:
            health = 0.0

    try:
        import re
        pytest_ini = (ROOT / "pyproject.toml").read_text()
        m = re.search(r"(\d+) passed", pytest_ini)
        test_count = float(m.group(1)) if m else 0.0
    except Exception:
        test_count = 0.0

    drift_mag = float(len(diff.get("delta", {})))
    proposals = ctx.get("proposals", [])
    selected = ctx.get("selected", [])
    plan = ctx.get("plan", [])
    prev = ctx.get("previous_cycle")
    prev_desc = (prev or {}).get("self_description", {}) if prev else {}
    model_delta = float(sum(1 for k in desc if desc.get(k) != prev_desc.get(k)))

    radius_gained = sum(p.get("radius_gain", 0) for p in selected)

    vector = {
        "C": health,
        "Cs": test_count,
        "D": float(desc.get("tools_count", 0)),
        "Ds": drift_mag,
        "E": float(len(proposals)),
        "F": float(len(selected)),
        "Fs": float(len(plan)),
        "G": 1.0 if ctx.get("acted") else 0.0,
        "Gs": 1.0 if val.get("validate") == "GO" else 0.0,
        "A": 1.0,
        "As": model_delta,
        "B": radius_gained,
    }
    ctx["state_vector"] = vector
    return vector



def step_record(ctx: dict) -> dict:
    """A — Escribir artefacto del ciclo."""
    state_vector = _compute_state_vector(ctx)
    cycle_record = {
        "cycle_number": ctx["cycle_number"],
        "timestamp": ctx["timestamp"],
        "self_description": ctx.get("self_description", {}),
        "diff": ctx.get("diff", {}),
        "issues": ctx.get("issues", []),
        "gains": ctx.get("gains", []),
        "proposals": ctx.get("proposals", []),
        "selected": ctx.get("selected", []),
        "validation": ctx.get("validation", {}),
        "radius_earned": sum(p.get("radius_gain", 0) for p in ctx.get("selected", [])),
        "state_vector": state_vector,
    }
    data = _load_cycles(SPIRAL_LOG)
    data["cycles"].append(cycle_record)
    data["total_radius"] += cycle_record["radius_earned"]
    data["current_cycle"] = None
    _save_cycles(SPIRAL_LOG, data)
    ctx["radius_earned"] = cycle_record["radius_earned"]
    ctx["total_radius"] = data["total_radius"]
    _print_step(9, "OK", f"Ciclo #{ctx['cycle_number']} registrado · radio ganado: +{cycle_record['radius_earned']:.2f}")
    return ctx



def step_reflect(ctx: dict) -> dict:
    """A# — Actualizar self-model, gradiente y memoria episódica (IDEAS 1+3)."""
    voice_id = ctx.get("_voice_id", "main")

    try:
        gs = _load_gs(GS_FILE)
        gs["spiral_loop"] = {
            "last_cycle": ctx["cycle_number"],
            "last_cycle_at": ctx["timestamp"],
            "total_radius": ctx["total_radius"],
            "last_gains": ctx.get("gains", []),
            "last_issues": ctx.get("issues", []),
            "validation": ctx.get("validation", {}),
        }
        GS_FILE.write_text(json.dumps(gs, indent=2, ensure_ascii=False))
    except (json.JSONDecodeError, OSError, ValueError):
        pass

    try:
        gradient = ctx.get("_gradient") or _load_gradient(GRADIENT_FILE, STEPS, voice_id)
        sv = ctx.get("state_vector", {})
        prev_cy = ctx.get("previous_cycle")
        prev_sv = (prev_cy or {}).get("state_vector", {}) if prev_cy else {}
        h_delta = float(sv.get("C", 0)) - float(prev_sv.get("C", sv.get("C", 0)))
        r_delta = float(sv.get("B", 0))
        v_pass = ctx.get("validation", {}).get("validate") == "GO"

        gradient["last_gradient"] = {
            "health_delta": round(h_delta, 2),
            "radius_delta": round(r_delta, 3),
            "validate_pass": v_pass,
        }
        pw = gradient.setdefault("proposal_weights", {})
        for p in ctx.get("selected", []):
            pid = p.get("id", "")
            if not pid:
                continue
            current = pw.get(pid, 1.0)
            delta = +0.05 if v_pass else -0.03
            pw[pid] = round(max(0.3, min(2.0, current + delta)), 3)

        _save_gradient(GRADIENT_FILE, gradient, voice_id)
    except (json.JSONDecodeError, OSError, ValueError):
        pass

    try:
        ep_data = _load_episodic(EPISODES_FILE)
        sv = ctx.get("state_vector", {})
        fp = _compute_fingerprint(ctx.get("issues", []), ctx.get("gains", []), sv)
        selected = ctx.get("selected", [])
        resolution = selected[0]["title"] if selected else "—"
        episode = {
            "cycle": ctx["cycle_number"],
            "at": ctx["timestamp"],
            "voice": voice_id,
            "fingerprint": fp,
            "issues": ctx.get("issues", []),
            "gains": ctx.get("gains", []),
            "resolution": resolution,
            "radius_gain": ctx.get("radius_earned", 0),
            "state_vector": sv,
            "validate_ok": ctx.get("validation", {}).get("validate") == "GO",
        }
        ep_data.setdefault("episodes", []).append(episode)
        _save_episodic(EPISODES_FILE, ep_data)
    except (json.JSONDecodeError, OSError, ValueError):
        pass

    _print_step(10, "OK", f"Self-model + gradiente + memoria episódica actualizados · radio: {ctx.get('total_radius', 0):.2f}")
    return ctx



def step_rest(ctx: dict) -> dict:
    """B — Resumen y pausa."""
    print()
    print(f"  {BOLD}{'─' * 52}{RST}")
    print(f"  {CYN}{BOLD}  ∿  Ciclo #{ctx['cycle_number']} completado{RST}")
    print(f"  {'─' * 52}")
    print(f"  Radio ganado este ciclo : {BOLD}+{ctx.get('radius_earned', 0):.2f}{RST}")
    print(f"  Radio total acumulado   : {BOLD}{ctx.get('total_radius', 0):.2f}{RST}")
    print(f"  Regresiones detectadas  : {RED if ctx.get('issues') else GRN}{len(ctx.get('issues', []))}{RST}")
    print(f"  Mejoras detectadas      : {GRN}{len(ctx.get('gains', []))}{RST}")
    print(f"  Validación              : validate={ctx.get('validation', {}).get('validate', '?')} · health={ctx.get('validation', {}).get('health', '?')}")
    if ctx.get("proposals"):
        print(f"\n  {BOLD}Propuestas para la próxima vuelta:{RST}")
        for p in ctx["proposals"]:
            pri = {"high": "🔴", "medium": "🟡", "low": "⚪"}.get(p["priority"], "·")
            print(f"    {pri} [{p['id']}] {p['title']}")
    print(f"\n  {DIM}La espiral continúa. El siguiente ciclo emerge desde radio {ctx.get('total_radius', 0):.2f}.{RST}")
    print()
    _print_step(11, "OK", "Ciclo cerrado · listo para la próxima vuelta")
    return ctx
